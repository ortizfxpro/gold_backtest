"""Starter XAUUSD Telegram signal backtester.

IMPORTANT: This is a starter template. Adapt parse_signal() to the channel's exact
message format and validate outcomes against your manual spreadsheet before use.
It does not place trades or send orders.
"""
from __future__ import annotations
import asyncio
import json
import logging
import os
import re
import sqlite3
from copy import copy
from datetime import datetime, timedelta, timezone
from pathlib import Path

import MetaTrader5 as mt5
import pandas as pd
from dotenv import load_dotenv
from openpyxl import load_workbook
from telethon import TelegramClient, events

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / os.getenv(
    "DB_PATH", "goldxion.sqlite3"
)
OUTPUT_XLSX = Path(
    os.getenv(
        "OUTPUT_XLSX",
        str(ROOT / "new_channel_backtest_output.xlsx")
    )
)
TEMPLATE_XLSX = Path(os.getenv("TEMPLATE_XLSX", "")) if os.getenv("TEMPLATE_XLSX") else None
SHEET_NAME = os.getenv("SHEET_NAME", "Result")
CHANNEL = os.getenv("TELEGRAM_CHANNEL", "https://t.me/XauusdExpertSignal_13")
MT5_SYMBOL = os.getenv("MT5_SYMBOL", "XAUUSD")
LOOKAHEAD_DAYS = int(os.getenv("LOOKAHEAD_DAYS", "7"))
HISTORY_LIMIT = int(os.getenv("HISTORY_LIMIT", "0"))  # 0 = all accessible history
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "60"))

# Excel columns modeled on the screenshot. Change these labels if your workbook differs.
HEADERS = ["Date", "Time (Here)", "Direction", "Entry Price", "SL",
           "TP1", "PnL", "Result", "TP2", "PnL", "Result",
           "TP3", "PnL", "Result"]


def db_connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS signals (
        chat_id TEXT NOT NULL, message_id INTEGER NOT NULL, message_date TEXT NOT NULL,
        raw_text TEXT NOT NULL, direction TEXT, entry REAL, sl REAL,
        tp1 REAL, tp2 REAL, tp3 REAL, excel_row INTEGER,
        PRIMARY KEY(chat_id, message_id))""")
    con.commit()
    return con



def parse_signal(text: str, message_date: datetime) -> dict | None:
    """Parse XAUUSD market and limit signals with one or more TP targets."""
    t = text.upper().replace(",", "")
    t = re.sub(r"[ \t]+", " ", t)

    if not re.search(r"\b(?:XAUUSD|GOLD)\b", t):
        return None

    # Identify direction and whether this is a market or limit entry.
    direction_match = re.search(r"\b(BUY|SELL)\b", t)
    if not direction_match:
        return None

    side = direction_match.group(1)

    if re.search(r"\bLIMIT\b", t):
        direction = f"{side.title()} Limit"
    else:
        direction = side.title()

    def find_price(pattern):
        match = re.search(pattern, t, re.I | re.M)
        return float(match.group(1)) if match else None

    # Entry: Price Now, Entry, or a price explicitly attached to BUY/SELL.
    entry = find_price(
        r"\bPRICE\s+NOW\s*[:=@-]?\s*(\d{3,5}(?:\.\d+)?)"
    )

    if entry is None:
        entry = find_price(
            r"\bENTRY(?:\s*PRICE)?\s*[:=@-]?\s*(\d{3,5}(?:\.\d+)?)"
        )

    if entry is None:
        entry = find_price(
            r"\b(?:BUY|SELL)\s+(?:NOW|LIMIT)\s+"
            r"(?:(?:XAUUSD|GOLD)\s+)?(\d{3,5}(?:\.\d+)?)"
        )

    # Stop loss.
    sl = find_price(
        r"\b(?:S\s*L|STOP\s*LOSS)\s*[:=@.\- ]+\s*"
        r"(\d{3,5}(?:\.\d+)?)"
    )

    # Accept TP, TP1/TP2/TP3, TARGET, and TAKE PROFIT.
    targets = [
        float(m.group(1))
        for m in re.finditer(
            r"\b(?:T\s*P\s*[1-3]?|TARGET\s*[1-3]?|TAKE\s*PROFIT)"
            r"\s*[:=@.\- ]+\s*(\d{3,5}(?:\.\d+)?)",
            t,
            re.I,
        )
    ]

    if entry is None or sl is None or not targets:
        logging.debug("Message did not match signal format: %r", text[:180])
        return None

    # Preserve the first three targets; leave unused targets empty.
    tp1 = targets[0]
    tp2 = targets[1] if len(targets) > 1 else None
    tp3 = targets[2] if len(targets) > 2 else None

    # Validate price direction.
    if side == "BUY":
        valid = sl < entry and all(
            tp > entry for tp in (tp1, tp2, tp3) if tp is not None
        )
    else:
        valid = sl > entry and all(
            tp < entry for tp in (tp1, tp2, tp3) if tp is not None
        )

    if not valid:
        logging.warning("Signal has inconsistent prices: %r", text[:180])
        return None

    return {
        "direction": direction,
        "entry": entry,
        "sl": sl,
        "tp1": tp1,
        "tp2": tp2,
        "tp3": tp3,
    }


def save_message(chat_id, msg_id, msg_date, text):
    con = db_connect()
    parsed = parse_signal(text or "", msg_date)
    if parsed is None:
        con.close()
        return False
    con.execute("""INSERT OR IGNORE INTO signals
        (chat_id,message_id,message_date,raw_text,direction,entry,sl,tp1,tp2,tp3)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (str(chat_id), int(msg_id), msg_date.astimezone(timezone.utc).isoformat(), text,
         parsed["direction"], parsed["entry"], parsed["sl"], parsed["tp1"], parsed["tp2"], parsed["tp3"]))
    con.commit()
    con.close()
    return True


def get_rates(start: datetime, end: datetime) -> pd.DataFrame:
    if not mt5.initialize():
        raise RuntimeError(f"MT5 initialize failed: {mt5.last_error()}. Open MT5 and log in first.")
    try:
        info = mt5.symbol_info(MT5_SYMBOL)
        if info is None:
            raise RuntimeError(f"MT5 symbol {MT5_SYMBOL!r} not found. Check broker's exact symbol, e.g. XAUUSD.a or GOLD.")
        if not info.visible:
            mt5.symbol_select(MT5_SYMBOL, True)
        rates = mt5.copy_rates_range(MT5_SYMBOL, mt5.TIMEFRAME_M1, start, end)
        if rates is None or len(rates) == 0:
            return pd.DataFrame()
        df = pd.DataFrame(rates)
        df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
        return df.sort_values("time").reset_index(drop=True)
    finally:
        mt5.shutdown()


def evaluate_target(signal, bars: pd.DataFrame, target: float | None) -> tuple[str, float | None]:
    """Evaluate one TP independently. PnL is measured in R-multiples."""

    if target is None:
        return "N/A", None

    entry = float(signal["entry"])
    sl = float(signal["sl"])
    risk = abs(entry - sl)

    if risk <= 0 or bars.empty:
        return "Pending", None

    direction = signal["direction"]
    is_buy = direction.startswith("Buy")
    is_market = direction in ("Buy", "Sell")

    # Market orders are treated as filled immediately.
    # Limit orders must first reach their entry price.
    filled = is_market

    for row in bars.itertuples(index=False):
        if not filled:
            touched = row.low <= entry if is_buy else row.high >= entry
            if not touched:
                continue
            filled = True

        stop_touched = row.low <= sl if is_buy else row.high >= sl
        target_touched = row.high >= target if is_buy else row.low <= target

        # M1 OHLC data cannot reliably establish which level was hit first.
        if stop_touched and target_touched:
            return "Ambiguous", None

        if stop_touched:
            return "Loss", -1.0

        if target_touched:
            return "Win", abs(target - entry) / risk

    return ("Open at end" if filled else "Pending"), None


def evaluate_signal(signal) -> dict:
    msg_time = datetime.fromisoformat(signal["message_date"])
    if msg_time.tzinfo is None:
        msg_time = msg_time.replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    end = min(now, msg_time + timedelta(days=LOOKAHEAD_DAYS))
    if end <= msg_time:
        return {"results": [("Pending", None)] * 3, "filled": False}
    bars = get_rates(msg_time, end)
    if bars.empty:
        return {"results": [("Pending", None)] * 3, "filled": False}
    results = [evaluate_target(signal, bars, signal[f"tp{i}"]) for i in (1, 2, 3)]
    filled = any(result not in ("Pending",) for result, _ in results) or any(
        (bars.low <= signal["entry"]).any() if signal["direction"] == "Buy Limit"
        else (bars.high >= signal["entry"]).any() for _ in [0])
    return {"results": results, "filled": filled}


def ensure_workbook():
    if OUTPUT_XLSX.exists():
        wb = load_workbook(OUTPUT_XLSX)
        ws = wb[SHEET_NAME] if SHEET_NAME in wb.sheetnames else wb.active
        return wb, ws
    if TEMPLATE_XLSX and TEMPLATE_XLSX.exists():
        wb = load_workbook(TEMPLATE_XLSX)
        ws = wb[SHEET_NAME] if SHEET_NAME in wb.sheetnames else wb.active
        return wb, ws
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = SHEET_NAME
    for col, value in enumerate(HEADERS, 1):
        ws.cell(1, col, value)
    return wb, ws


def write_signal_to_excel(row_data, signal_key):
    wb, ws = ensure_workbook()
    con = db_connect()
    record = con.execute("SELECT excel_row FROM signals WHERE chat_id=? AND message_id=?", signal_key).fetchone()
    row_num = record["excel_row"] if record and record["excel_row"] else None
    if row_num is None:
        row_num = ws.max_row + 1
        # Copy formatting from the previous data row when one exists.
        if row_num > 2:
            for col in range(1, max(ws.max_column, len(row_data)) + 1):
                src, dst = ws.cell(row_num - 1, col), ws.cell(row_num, col)
                if src.has_style:
                    dst._style = copy(src._style)
                if src.number_format:
                    dst.number_format = src.number_format
                if src.alignment:
                    dst.alignment = copy(src.alignment)
        con.execute("UPDATE signals SET excel_row=? WHERE chat_id=? AND message_id=?", (row_num, *signal_key))
        con.commit()
    for col, value in enumerate(row_data, 1):
        ws.cell(row_num, col, value)
    wb.save(OUTPUT_XLSX)
    con.close()


def process_signal(signal):
    evaluation = evaluate_signal(signal)
    results = evaluation["results"]
    dt = datetime.fromisoformat(signal["message_date"]).astimezone()  # local display time
    row = [dt.strftime("%Y.%m.%d"), dt.strftime("%H:%M"), signal["direction"],
           signal["entry"], signal["sl"]]
    for idx, (status, pnl) in enumerate(results, start=1):
        row.extend([signal[f"tp{idx}"], pnl if pnl is not None else 0, status])
    write_signal_to_excel(row, (signal["chat_id"], signal["message_id"]))
    logging.info("Updated message %s: %s", signal["message_id"], [x[0] for x in results])


def process_all_saved():
    con = db_connect()
    signals = con.execute("SELECT * FROM signals ORDER BY message_date, message_id").fetchall()
    con.close()
    for signal in signals:
        try:
            process_signal(dict(signal))
        except Exception:
            logging.exception("Failed to process Telegram message %s", signal["message_id"])


async def main():
    api_id = os.getenv("TELEGRAM_API_ID")
    api_hash = os.getenv("TELEGRAM_API_HASH")
    if not api_id or not api_hash:
        raise RuntimeError("Set TELEGRAM_API_ID and TELEGRAM_API_HASH in .env first.")
    client = TelegramClient(str(ROOT / "telegram_session"), int(api_id), api_hash)
    await client.start()  # First run asks for your Telegram phone/login code.
    entity = await client.get_entity(CHANNEL)
    chat_id = getattr(entity, "id", CHANNEL)

    logging.info("Importing accessible historical messages from %s", CHANNEL)
    count = 0
    async for msg in client.iter_messages(entity, limit=(HISTORY_LIMIT or None), reverse=True):
        if not msg.message:
            continue
        if save_message(chat_id, msg.id, msg.date, msg.message):
            count += 1
    logging.info("Imported %d newly parsed signals. Recalculating workbook...", count)
    process_all_saved()

    @client.on(events.NewMessage(chats=entity))
    async def new_message_handler(event):
        text = event.raw_text or ""
        if save_message(chat_id, event.id, event.date, text):
            logging.info("New signal parsed: message %s", event.id)
            process_all_saved()
        else:
            logging.info("New message %s did not match parser; review raw message manually.", event.id)

    @client.on(events.MessageEdited(chats=entity))
    async def edited_message_handler(event):
        # Edits can change entry/SL/TP. Update stored parsed values if the edited message still parses.
        parsed = parse_signal(event.raw_text or "", event.date)
        if not parsed:
            logging.warning("Edited message %s no longer parses; review it manually.", event.id)
            return
        con = db_connect()
        con.execute("""UPDATE signals SET raw_text=?, message_date=?, direction=?, entry=?, sl=?, tp1=?, tp2=?, tp3=?
            WHERE chat_id=? AND message_id=?""",
            (event.raw_text, event.date.astimezone(timezone.utc).isoformat(), parsed["direction"],
             parsed["entry"], parsed["sl"], parsed["tp1"], parsed["tp2"], parsed["tp3"], str(chat_id), event.id))
        con.commit(); con.close()
        process_all_saved()
        logging.info("Reprocessed edited message %s", event.id)

    async def periodic_refresh():
        while True:
            await asyncio.sleep(POLL_SECONDS)
            process_all_saved()  # Pending live signals are re-evaluated as price history grows.

    asyncio.create_task(periodic_refresh())
    logging.info("Listening for new channel messages. Press Ctrl+C to stop.")
    await client.run_until_disconnected()


if __name__ == "__main__":
    asyncio.run(main())
